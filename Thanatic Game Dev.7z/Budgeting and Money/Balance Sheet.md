Expenses:
Games to Purchase for Inspiration:
- [ ] The Backrooms: Survival: $9.99

Revenue: