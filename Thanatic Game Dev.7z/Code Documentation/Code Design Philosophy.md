"I think the most healthy mindset a programmer can possibly have is basically how can I solve the problems at hand effectively (note: without solving tomorrows problems as well) with as little code and as few dependencies as humanly possible WHILE imagining that I will die in a car crash tonight and a junior dev straight out of school is going to take over the project tomorrow." -Some dude on YouTube I found

Please read the Design Document, Master To Do, Core Feature List, and 2D/3D Documentation before contributing code so that you know what we are looking to code ahead of time. This will save you the heartache of making something that will not be implemented.

Here are some quick guidelines on what we should implement immediately so it's not a later hassle to coders:
-Multiplayer Support
-Multi GUI Support
-Random Dungeon Generation. They had this shit figured out in the 90s, new developers are just fucking rarted. Liberate the code from stack overflow if possible and make it better if you're in doubt.
-Base Building/Georama support. I should be able to place objects in the vein of Surrounded, even in dungeons to build a base from within. High Risk, High Reward.
-NPC AI, Dialogue, friendly and enemy. 