Code blocks can be inserted into Obsidian by right clicking. Here is an example one:
```





```


Knock yourself out :3