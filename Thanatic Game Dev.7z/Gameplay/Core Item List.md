Consumables:
- [ ] Bandages
- [ ] First Aid Kit
- [ ] Potato for Food

Weapons:
- [ ] Generic Ammunition
- [ ] Generic Rifle
- [ ] Sword
