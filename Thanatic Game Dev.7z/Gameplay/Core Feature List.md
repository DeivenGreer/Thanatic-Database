Tech Demo Features:
- [ ] Walking
	- [ ] Sprinting (Infinite Stamina)
	- [ ] Crouching
- [ ] Camera/Looking
	- [ ] Aiming/Zoom
- [ ] Basic Enemy AI
	- [ ] Movement

Core Gameplay Loops for Tech Demo:
- [ ] Walking simulation into dungeon from aboveground
- [ ] Kill enemy - receive ammo/health/armor/weapon -repeat
- [ ] Dungeon stops at Level 5, and Tech Demo Credits roll with a thank you notice

Game Demo Features:
- [ ] NPC AI & Realtime Dialogue Prompts
- [ ] Enemy AI
	- [ ] Attacking
	- [ ] Dodging
	- [ ] Taking Cover
	- [ ] Morale/Running Away
- [ ] Locking On to target when UI is equipped


CORE GAMEPLAY LOOPS FOR GAME DEMO:
- [ ] Gather/Loot Materials - Craft Tools/Weapons - Kill Enemies - Repeat
- [ ] Hunger/Thirst/Sleep increase - Build Base Camp - Enemies attack in dungeon camp waypoints or above ground - Enemies drop loot - Repeat
- [ ] Rescue People - NPC Interaction/trade/companions - Rescue more people/building structures
- [ ] Enter the dungeon with your human body - kill a drone or android - hack machine remotely while your body is in suspended animation and vulnerable - upgrade robots, human body, and transference machine (rebirther)- repeat until you can protect yourself.


Gameplay Loops for Full Release: