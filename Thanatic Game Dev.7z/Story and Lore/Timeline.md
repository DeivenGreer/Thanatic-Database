Present Time: The game takes place on April 2029. What is not explained to the player is that the game begins 24 hours before the comet Apophis strikes the earth, ushering in the time of Revelation and coating the earth in fire. Any player caught in the blast will be burned to death horribly, and must create a new character due to the permadeath system.


