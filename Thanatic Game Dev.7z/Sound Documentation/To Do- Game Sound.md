Immediate:
- [x] CREATE SOUND LIBRARY
- [x] Establish CORE SOUND EFFECTS necessary to create initial gameplay loop
- [x] Establish CORE MUSIC DESIGN necessary.
- [ ] Establish what programs are necessary to download, if any.

Long-Term:
- [ ] Upload game soundtrack to Spotify, YouTube, Soundcloud, Steam, and Bandcamp for purchase officially. Make it 2 dollars and optional. Make it allowable for people to use it in any videos on YouTube, and encourage remixes.
- [ ] Create 2 competitions for the game music. No money is to be exchanged:
	- [ ] Best remix will be put into the game, by players choice. Developer reserves the right to add multiple songs. Full credit will be listed in game to the song creator.
	- [ ] Best new song will be put into the game by the players choice. Developer reserves the right to add multiple songs. Full credit will be listed in game to the song creator.