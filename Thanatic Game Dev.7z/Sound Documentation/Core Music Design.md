Primary Inspirations: (Click their to-do button when you feel like you've accomplished the task.)
- [ ] Fear and Hunger (Dark, brooding, fucked up noise without a UI to help you.)
- [ ] Final Fantasy 8 (Music inspiration)
- [ ] Silent Hill 2 (Use of silence to haunt you.)

Necessary Songs/Core Gameplay Loop:
- [ ] ***!!!Title Track!!!!***
- [ ] Ambient Song for above-ground level
- [ ] Ambient Songs for first 3 layers of the dungeon
- [ ] 3 tracks of *mostly* silence. Random heartbeats, wind blowing, and rustling should scare the fuck out of players.
- [ ] 3 Battle Themes like Fear and Hunger
