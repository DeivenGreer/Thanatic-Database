This is the 80/20 tracker for the game in order to create easy wins for a tech demo to recruit other members. Speak of this game to no one until you have a product. Develop it every day, even if it's small progress. If you are off a full day, dedicate the day to it. Read this To Do daily when confused. Never close obsidian and make this your primary desktop environment when shutting down for the day.

80/20:
- [x] -Establish Master Lists:
	- [x] To Do for Game Sound
	- [x] To Do for Game UI
	- [x] To Do for 3D Environment
	- [x] To Do for 2D Environment
	- [x] Establish Design Document
	- [x] Establish Story Document
	- [ ] Establish a schedule of deadlines for consistent progress
	- [x] Convert an old discord group into Game Dev
- [ ] Accomplish a major goal for each master list each day that is not just writing on Obsidian other than the Design Document (Sanity Check). It needs to be a deliverable, physical product. Check and reset this list daily.
	- [ ] Game Sound
	- [ ] Game UI
	- [ ] 3D Environment
	- [ ] 2D Environment
	- [ ] Read and Write Design Documentation

Things that would be nice to have:
- [ ] 