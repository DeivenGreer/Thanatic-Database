All series listed are directly relevant to developing this game, and investigating them is considered work upon it. By no means are they gospel, but tools to be used. Each game will come with a link for easy access, and if you don't have time, a Let's Play will be hyperlinked in parenthetical (If there is one). Please prioritize the Emulation section first- older is, unfortunately, higher quality.

Emulation:
- PS2 Emulator: https://pcsx2.net/
- PS2 BIOS: https://archive.org/download/ps1-2-BIOS/Playstation%202%20BIOS%20Collection/
- Dark Cloud: https://cdromance.org/ps2-iso/dark-cloud-usa/
- Panzer Dragoon Orta: https://www.youtube.com/watch?v=W2fUAUb3Ksc
- PSP Emulator: https://www.ppsspp.org/
- Rengoku: Tower of Purgatory: https://cdromance.org/psp/rengoku-the-tower-of-purgatory-usa/ (https://www.youtube.com/watch?v=-jHVhL1WiuE) (This game is Warframe before Warframe and FAR more modular, and offline. Recommended.)

Free Games:
- Entity Researchers: https://store.steampowered.com/app/2001380/Entity_Researchers_Prologue/
- Warframe: https://store.steampowered.com/app/230410/Warframe/

Paid Games:

- Fear and Hunger: https://store.steampowered.com/app/1002300/Fear__Hunger/
- DeadPoly: https://store.steampowered.com/app/1621070/DeadPoly/

