All of the following have expressed interest to me in the past to create games. They should be contacted for development positions as they arise/When we are far enough to not scare them off:

Template: -Name (Handle) (Most likely positions from their preferences and strengths that I'm aware of)

-Jon Bruce (BlueBukkitDev) (Coding and Development)
-Wyatt Ohara (Centerion) (3D Assets, Ballistics, and Rendering)
-Brett Johnson (Rikku) (Design, Development, and Business)
-Tyler Velazquez (Zanik) (Art Direction, Monster Design, 3D Design, and Lore)
-Kota Chorazak (Lemon891) (Coding, Marketing, Short Form Media, User Experience)
-Aries Chorazak (Skyefox767) (Voice Acting, Playtesting, Coding)
-Jared Enger (CyberTheNerd) (Unsure, but has excellent taste in Writing)
-Hayden Cottril (Music Design, Sound Design, Possible Voice Acting)
-Morgan Herring (Pixel Art, Storyboarding, Lore, Writing, Possible Voice Acting)
-James McNeil (Music Contribution, ANYTHING Engineering. Nuclear Engineer.)


Here is a list of good friends that would very likely playtest but be unlikely to develop:
-Trev Christensan (Jiu-Jitsu competitor, and practically my older brother)
-Oscar Cantor (Would make an excellent team lead for technical work if he ever had time away from missile defense)
-NekoMangoGames (V-tuber, close friend from high school, excellent marketing acumen.)
-Travis Brannon (Possible music contribution)
-Blake Deal (Pastor, Cousin, Friend. He got me into Halo, and shooters in general.)
-Sean Berlin (Best technician I met in my tenure in the navy. Engineer.)
-Mike Stephens (Old friend, extremely supportive.)
-William Laney (Cattle Rancher, and long time friend. Texas personified)
-Alex Billings (CIWS Technician, and an excellent friend. May be busy.)
-Sherard Julien (Possible music contribution, and writer. Would love his thoughts.)
-Christian Price-Glunz (One of the best I've met in the military. Also a massive nerd like me.)
-Gilliland Hobbs (Film director and screenwriter. Would be good for critiques from a boomer perspective.)
-Daniel Pate (Combat veteran, survived 9 IED strikes on his record. Consult for combat, and playability.)
-Dalan Stockton (COD top 10 player, loves my demented ideas for game dev.)

